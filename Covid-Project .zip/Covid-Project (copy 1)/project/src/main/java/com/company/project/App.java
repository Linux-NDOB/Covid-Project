package com.company.project;


public  class App {
    
    public static void main(String[] args) {
       Covid obj = new Covid();
   
       obj.setDatos();
    }
}
